(() => {
  'use strict';

  /* ---------- 25-frame gaze engine ---------- */
  const canvas = document.getElementById('characterCanvas');
  const hero = document.getElementById('hero');
  const ctx = canvas.getContext('2d');
  const frameCache = {};
  const IDLE = { row: 3, col: 4 };
  let current = { ...IDLE };
  let drawn = null;          // key of the frame currently on canvas
  let queued = false;
  let cw = 0, ch = 0;

  // Asymmetric horizontal steps (more on the left), uniform vertical steps.
  const COL_EDGES = [15, 35, 55, 75];
  const ROW_EDGES = [20, 40, 60, 80];
  const bucket = (pct, edges) => edges.findIndex(e => pct < e) + 1 || edges.length + 1;

  const preload = () => Promise.all(
    Array.from({ length: 25 }, (_, i) => {
      const r = Math.floor(i / 5) + 1, c = (i % 5) + 1, key = `${r}-${c}`;
      return new Promise(res => {
        const img = new Image();
        img.onload = img.onerror = () => { frameCache[key] = img; res(); };
        img.src = `assets/frames/r${r}c${c}.jpg`;
      });
    })
  );

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = hero.getBoundingClientRect();
    cw = rect.width; ch = rect.height;
    canvas.width = Math.round(cw * dpr);
    canvas.height = Math.round(ch * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawn = null;
    schedule();
  }

  // object-fit: cover, anchored right/bottom so the character and floor stay put.
  function draw() {
    queued = false;
    const key = `${current.row}-${current.col}`;
    if (key === drawn) return;                 // redraw only when the frame changes
    const img = frameCache[key];
    if (!img || !img.naturalWidth) return;
    const s = Math.max(cw / img.naturalWidth, ch / img.naturalHeight);
    const w = img.naturalWidth * s, h = img.naturalHeight * s;
    ctx.drawImage(img, -(w - cw) * 0.78, -(h - ch), w, h);
    drawn = key;
  }
  function schedule() { if (!queued) { queued = true; requestAnimationFrame(draw); } }

  function setFromPoint(x, y) {
    const rect = hero.getBoundingClientRect();
    const px = Math.min(Math.max((x - rect.left) / rect.width * 100, 0), 100);
    const py = Math.min(Math.max((y - rect.top) / rect.height * 100, 0), 100);
    const next = { col: bucket(px, COL_EDGES), row: bucket(py, ROW_EDGES) };
    if (next.col !== current.col || next.row !== current.row) { current = next; schedule(); }
  }
  function setIdle() {
    if (current.row !== IDLE.row || current.col !== IDLE.col) { current = { ...IDLE }; schedule(); }
  }

  // Touch / coarse pointers: pan to look, plus an ambient loop when untouched.
  const coarse = matchMedia('(pointer: coarse)').matches;
  const AMBIENT = [[3,4],[2,3],[2,4],[3,5],[4,4],[4,5],[3,4],[3,2],[3,3],[4,3]];
  let ambientTimer = null, ambientIdx = 0, lastTouch = 0;
  function startAmbient() {
    if (ambientTimer) return;
    ambientTimer = setInterval(() => {
      if (Date.now() - lastTouch < 3000 || document.hidden) return;
      const [row, col] = AMBIENT[ambientIdx++ % AMBIENT.length];
      current = { row, col }; schedule();
    }, 1600);
  }

  function bindTracking() {
    if (!coarse) {
      window.addEventListener('mousemove', e => setFromPoint(e.clientX, e.clientY), { passive: true });
      document.addEventListener('mouseleave', setIdle);
      window.addEventListener('blur', setIdle);
    }
    const touch = e => { lastTouch = Date.now(); const t = e.touches[0]; setFromPoint(t.clientX, t.clientY); };
    hero.addEventListener('touchstart', touch, { passive: true });
    hero.addEventListener('touchmove', touch, { passive: true });
    if (coarse || matchMedia('(max-width: 1024px)').matches) startAmbient();
  }

  window.addEventListener('resize', resize);
  preload().then(() => { resize(); bindTracking(); });   // listeners bind only after all 25 frames are cached

  /* ---------- Navigation ---------- */
  const nav = document.getElementById('nav');
  const burger = document.getElementById('burger');
  const setMenu = open => {
    nav.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', open);
    document.body.style.overflow = open ? 'hidden' : '';
  };
  burger.addEventListener('click', () => setMenu(!nav.classList.contains('open')));
  document.querySelectorAll('#navLinks a').forEach(a => a.addEventListener('click', () => setMenu(false)));
  document.addEventListener('keydown', e => e.key === 'Escape' && setMenu(false));

  document.getElementById('toTop').addEventListener('click', e => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ---------- Scroll reveals (staggered) ---------- */
  document.querySelectorAll('.reveal').forEach(el => {
    const siblings = [...el.parentElement.children].filter(c => c.classList.contains('reveal'));
    el.style.setProperty('--i', siblings.indexOf(el));
  });
  document.querySelectorAll('.steps li').forEach(el => el.classList.add('reveal'));
  const io = new IntersectionObserver(entries => entries.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
  }), { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
})();
